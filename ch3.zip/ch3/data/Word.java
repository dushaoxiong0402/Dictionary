package ch3.data;
public class Word{
   String englishWord;
   String meaning;
   public void setEnglishWord(String englishWord){
      this.englishWord = englishWord;
   }
   public String getEnglishWord() {
      return englishWord;
   }
   public void setMeaning(String meaning){
      this.meaning = meaning;
   }
   public String getMeaning() {
      return meaning;
   }
}
